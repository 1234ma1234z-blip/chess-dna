# Chess DNA Complete

## Install in Codespaces
```bash
npm install
npm run dev
```
`npm install` downloads Stockfish 18.0.8 and copies the mobile-friendly single-thread WebAssembly engine into `public/engine`.

## Included
- Interactive legal chessboard
- Stockfish 18 loader, evaluation, depth and PV
- MultiPV command
- PGN import
- Four offline verified-format puzzle records, with architecture for Lichess CSV ingestion
- 40 tactical concepts
- 24 opening families with recall evidence
- Spaced-evidence foundation persisted in localStorage
- Confidence-gated Chess DNA
- PWA manifest and service worker

## Data scale
Do not bundle the complete Lichess databases into the mobile client. Ingest the CC0 puzzle/evaluation archives into a server-side indexed store and stream personalized records to the app.
