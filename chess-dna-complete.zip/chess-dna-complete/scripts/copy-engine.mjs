import fs from 'node:fs';import path from 'node:path';
const src='node_modules/stockfish/bin',out='public/engine';fs.mkdirSync(out,{recursive:true});
if(!fs.existsSync(src)){console.log('Stockfish package not present yet');process.exit(0)}
const files=fs.readdirSync(src);let chosen=files.filter(x=>x.includes('18-lite-single')&&(x.endsWith('.js')||x.endsWith('.wasm')));
if(!chosen.length)chosen=files.filter(x=>x.includes('18-single')&&(x.endsWith('.js')||x.endsWith('.wasm')));
for(const f of chosen)fs.copyFileSync(path.join(src,f),path.join(out,f));
fs.writeFileSync(path.join(out,'engine-files.json'),JSON.stringify(chosen));console.log('Copied Stockfish 18:',chosen.join(', '));
