# Chess DNA V1
Mobile-first adaptive chess intelligence application shell.

## Run
npm install
npm run dev

## Current real functions
- Persistent local evidence store
- Evidence-gated Chess DNA scoring (no score until 3 observations)
- 24-family opening knowledge seed
- Tactical curriculum taxonomy seed
- Legal interactive analysis board powered by chess.js
- Mobile-first PWA manifest and navigation

## Engine integration target
Stockfish 18 WebAssembly worker, MultiPV, evaluation and move classification. The UI explicitly does not fabricate engine output before that worker is installed.
