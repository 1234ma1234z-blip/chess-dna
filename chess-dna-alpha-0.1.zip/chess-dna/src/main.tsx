import React,{useMemo,useState} from 'react';
import{createRoot}from'react-dom/client';
import{Chess}from'chess.js';
import'./style.css';

type Skill={name:string,score:number,kind:string};
const skills:Skill[]=[
{name:'Opening Intelligence',score:72,kind:'knowledge'},
{name:'Tactical Vision',score:81,kind:'vision'},
{name:'Calculation',score:68,kind:'thinking'},
{name:'Positional Understanding',score:63,kind:'strategy'},
{name:'Prophylaxis',score:54,kind:'defense'},
{name:'Endgames',score:57,kind:'technique'}];
const repertoire=['Italian Game','Caro-Kann Defense','Queen’s Gambit Declined'];
function Bar({v}:{v:number}){return <div className="bar"><i style={{width:v+'%'}}/></div>}
function DNA(){return <section><div className="hero"><div><small>YOUR PLAYER MODEL</small><h1>Chess DNA</h1><p>Not a rating. A living map of how you think.</p></div><div className="score">67<small>/100</small></div></div><div className="grid">{skills.map(s=><article className="card" key={s.name}><div className="row"><b>{s.name}</b><strong>{s.score}</strong></div><Bar v={s.score}/><small>{s.kind.toUpperCase()} · confidence: developing</small></article>)}</div><article className="focus"><span>🔥 Highest improvement ROI</span><h2>Prophylaxis</h2><p>You spot immediate tactics better than long-term counterplay. Today's plan emphasizes opponent-intent recognition.</p><button>Start 18-minute prescription</button></article></section>}
function Openings(){return <section><h1>Opening Intelligence</h1><p className="sub">Your active repertoire stays small while the knowledge graph grows underneath it.</p>{repertoire.map((x,i)=><article className="line" key={x}><div><b>{x}</b><small>{['White · 1.e4','Black vs 1.e4','Black vs 1.d4'][i]}</small></div><div>{[76,61,48][i]}% mastered</div></article>)}</section>}
function Puzzles(){const [n,setN]=useState(0);let items=['Fork · recognize','Deflection · execute','Interference · defend','Zwischenzug · combine'];return <section><h1>Tactical Intelligence</h1><p className="sub">We train the motif, the context, and the thinking skill, not just a puzzle rating.</p><article className="puzzle"><small>ADAPTIVE DRILL {n+1}/4</small><h2>{items[n]}</h2><div className="fakeboard">♜ ♞ ♝ ♛<br/>♟ ♟ ♟ ♟<br/><br/>♙ ♙ ♙ ♙<br/>♖ ♘ ♗ ♕</div><p>Middlegame · estimated solve probability 64%</p><button onClick={()=>setN((n+1)%4)}>I found the idea →</button></article></section>}
function Board(){const [game,setGame]=useState(new Chess());const moves=useMemo(()=>game.moves().slice(0,12),[game]);function play(m:string){const g=new Chess(game.fen());try{g.move(m);setGame(g)}catch{}}return <section><h1>Chess Lab</h1><p className="sub">Legal-move foundation is alive. Tap a candidate move from the current position.</p><article className="card"><p className="fen">{game.fen()}</p><div className="moves">{moves.map(m=><button key={m} onClick={()=>play(m)}>{m}</button>)}</div><button className="ghost" onClick={()=>setGame(new Chess())}>Reset</button></article></section>}
function App(){const [tab,setTab]=useState('dna');return <main><header><div className="brand">♞ <b>CHESS DNA</b><em>alpha 0.1</em></div><div className="avatar">M</div></header><div className="content">{tab==='dna'?<DNA/>:tab==='open'?<Openings/>:tab==='puz'?<Puzzles/>:<Board/>}</div><nav>{[['dna','🧬','DNA'],['open','♟','Openings'],['puz','⚔️','Tactics'],['lab','🧠','Lab']].map(x=><button className={tab===x[0]?'active':''} onClick={()=>setTab(x[0])} key={x[0]}><span>{x[1]}</span>{x[2]}</button>)}</nav></main>};
createRoot(document.getElementById('root')!).render(<App/>);
