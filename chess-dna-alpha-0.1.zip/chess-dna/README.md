# Chess DNA alpha 0.1

Phone-first proof of existence for the adaptive chess-learning system.

## Run from a phone using GitHub Codespaces
1. Create a GitHub repository and upload this project.
2. Open the repository in GitHub Codespaces from your phone browser.
3. In its terminal run: `npm install`
4. Run: `npm run dev`
5. Open the forwarded port in browser.

## Implemented in alpha 0.1
- Chess DNA dashboard and improvement-ROI concept
- Opening Intelligence repertoire screen
- Tactical Intelligence adaptive-drill prototype
- Working legal-move chess.js lab
- Mobile-first navigation and responsive interface

## Next engineering milestones
- Real graphical chessboard with drag/tap moves
- Supabase authentication + persistent player model
- Lichess game import
- Stockfish WebAssembly worker
- Event/evidence schema and confidence-weighted DNA updater
- Lichess puzzle ingestion pipeline
